$(document).ready(function(){
    new Settings({'href' : '/admin/settings/index'});
});